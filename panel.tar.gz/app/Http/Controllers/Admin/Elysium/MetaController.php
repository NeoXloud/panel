<?php

namespace Pterodactyl\Http\Controllers\Admin\skynest;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class MetaController extends Controller
{
    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    public function __construct(
        AlertsMessageBag $alert
    ) {
        $this->alert = $alert;
    }

    public function index()
    {
        $skynest = DB::table('skynest')->first();

        return view('admin.skynest.meta', ['skynest' => $skynest,]);
    }

    public function update(Request $request)
    {
        $existing = DB::table('skynest')->first();
        DB::table('skynest')->where('id', $existing->id)->update([
            'logo' => $request->logo, 
            'title' => $request->title, 
            'description' => $request->description, 
            'color_meta' => $request->color_meta, 
            'updated_at' => \Carbon::now(),
        ]);

        $this->alert->success('Skynest Theme settings have been updated successfully.')->flash();
        return redirect()->back();
    }
}
