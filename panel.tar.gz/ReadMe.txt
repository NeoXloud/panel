Thank you for purchasing my Elysium Theme for Pterodactyl v1.11.x!!

#How to install?:

1. Make sure you have the dependencies for building the Panel assets:
| https://pterodactyl.io/community/customization/panel.html

2. Open and upload the folder to the directory /var/www/pterodactyl

3. When the file has been successfully uploaded, run the following command:
| cd /var/www/pterodactyl
| php artisan migrate
| > yes
| yarn build:production
| php artisan optimize:clear

4. Done!, the theme was successfully applied and can be used!
| You can customize this theme on Admin > Elysium Theme

# Bugs & Help:
| Did you find a problem with the theme?
| Do you have difficulty installing the theme?

If you have any problems you can contact us in the following discord server: https://discord.gg/rBuseTnRBq